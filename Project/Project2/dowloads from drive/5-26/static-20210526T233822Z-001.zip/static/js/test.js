function test(sliderValue){
console.log(sliderValue + "hello");
};

function test1(data){
    console.log(data);
}